<?php

namespace App\App;

final class Constants
{
    public const FILE_UPLOAD_BASE_DIR = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'uploads';
}
