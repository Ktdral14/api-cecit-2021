<?php

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;
